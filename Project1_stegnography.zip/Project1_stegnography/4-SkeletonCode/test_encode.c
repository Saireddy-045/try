#include <stdio.h>
#include "encode.h"
#include "types.h"
#include <string.h>
#include "common.h"
#include "decode.h"
/*
name : k.sai kumar reddy
rollno : 24017wp_010
*/
int main(int argc, char *argv[])
{
    EncodeInfo encInfo;
    DecodeInfo decInfo;
    uint img_size;
    // validation --> check if CLA has atleast 3 arguments
    if ( argc >= 1)
    {
        if ( argc >= 3)
        {
            int ret = check_operation_type(argv);
            if ( ret == e_encode)
            {
                printf("Selected encoding\n");
                if (argc >= 4)
                {
                    if (read_and_validate_encode_args(argv,&encInfo) == e_success)
                    {
                        printf("Read and Validation is successfull.\n");
                        printf("Started Encoding\n");
                        if(do_encoding(&encInfo) == e_success)
                        {
                            printf("Encoded done\n");
                        }
                        else
                        {
                            printf("Failed to encode\n");
                        }
                    }
                    else
                    {
                        printf("Read and validation is failed\n");
                    }
                }
                else
                {
                    printf("Required no.of arguements are not provided\n");
                }
            }
            else if ( ret == e_decode)
            {
                printf("Selected decoding\n");
                if (argc >= 3)
                {
                    if (read_and_validate_decode_args(argv,&decInfo) == e_success)
                    {
                        printf("Read and Validation is successfull.\n");
                        printf("Started Decoding\n");
                        if(do_decoding(&decInfo) == e_success)
                        {
                            printf("Decoded done\n");
                        }
                        else
                        {
                        printf("Failed to Decode\n");
                        }
                    }
                    else
                    {
                      printf("Read and Validation is failed\n");
                    }
                }
                  else
                  {
                  return e_failure;
                  }
            }
            else
            {
                printf("Unsupported Format\n");
                return e_failure;
            }
        }
        else
        {
            printf("Required no.of arguements are not provided\n");
            return e_failure;
        }
    }
    else
    {
        printf("No arguements passed\n");
    }
}
OperationType check_operation_type(char *argv[])
{
    if (strcmp(argv[1], "-e") == 0)
    {
        return e_encode;
    }
    else if (strcmp(argv[1], "-d") == 0)
    {
        return e_decode;
    }
    else
    {
        return e_unsupported;
    }
}
