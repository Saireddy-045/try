#ifndef COMMON_H
#define COMMON_H

/* Magic string to identify whether stegged or not */

//#define MAGIC_STRING "#*"
#define MAGIC_STRING_LEN 4  


#endif
