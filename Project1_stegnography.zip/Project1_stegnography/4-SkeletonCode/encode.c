#include <stdio.h>
#include "encode.h"
#include "types.h"
#include <string.h>
#include "common.h"

/* Get image size
    Input: Image file ptr
    Output: width * height * bytes per pixel (3 in our case) 
*/

uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    // Seek to 18th byte
    fseek(fptr_image, 18, SEEK_SET);

    // Read the width (an int)
    fread(&width, sizeof(int), 1, fptr_image);
    printf("width = %u\n", width);

    // Read the height (an int)
    fread(&height, sizeof(int), 1, fptr_image);
    printf("height = %u\n", height);

    // Return image capacity
    return width * height * 3;
}

/*
 * Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file and
 * Stego Image file
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors
 */
Status open_files(EncodeInfo *encInfo)
{
    // Src Image file
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r"); // beautiful.bmp
    // Do Error handling
    if (encInfo->fptr_src_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);

        return e_failure;
    }

    // Secret file
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    // Do Error handling
    if (encInfo->fptr_secret == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);

        return e_failure;
    }

    // Stego Image file
    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "w");
    // Do Error handling
    if (encInfo->fptr_stego_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);

        return e_failure;
    }

    // No failure return e_success
    return e_success;
}

Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
    if (strstr(argv[2], ".") != NULL)
    {
        if(strcmp(strstr(argv[2], "."), ".bmp") == 0)
        {
            encInfo->src_image_fname = argv[2]; // beautiful.bmp
        }
        else
        {
            printf("No bmp file is found in argv[2]\n");
            return e_failure;
        }
    }
    else
    {
        printf("No extension is found in the given file\n");
        return e_failure;
    }
    if (strstr(argv[3], ".") != NULL)
    {
        if(strcmp(strstr(argv[3], "."), ".txt") == 0)
        {
            encInfo->secret_fname = argv[3]; // secret.txt
        }
        else
        {
            printf("No .txt file is found in argv[3]\n");
            return e_failure;
        }
    }
    else
    {
        printf("No secret file is found in argv[3]\n");
        return e_failure;
    }
    if (argv[4] != NULL)
    {
        encInfo->stego_image_fname = argv[4];
    }
    else
    {
        encInfo->stego_image_fname = "stego.bmp";
    }
    return e_success;
    
 }

Status check_capacity(EncodeInfo *encInfo)
{
    encInfo -> image_capacity = get_image_size_for_bmp(encInfo -> fptr_src_image); // stores the files size
    fseek(encInfo -> fptr_secret,0,SEEK_END);
    encInfo -> size_secret_file = ftell(encInfo -> fptr_secret);

    int size_of_extn = strlen(encInfo -> extn_secret_file);
    if(get_file_size(encInfo -> fptr_src_image) >= (54 + 4+ 4 + encInfo ->size_secret_file)*8)
    {
        return e_success;
    }
    else
    {
        return e_failure;
    }
}

uint get_file_size(FILE *fptr)
{
    fseek(fptr,0,SEEK_END);
    uint size=ftell(fptr);
    fseek(fptr,0,SEEK_SET);
    return size;
}

Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image)
{
    char copy[54];
    rewind(fptr_src_image);
    rewind(fptr_dest_image);
    fread(copy,54,1,fptr_src_image);
    fwrite(copy,54,1,fptr_dest_image);
    return e_success;
}
Status encode_magic_string(EncodeInfo *encInfo)
{
    // Prompt for the magic string interactively
    printf("Enter the magic string for encoding: ");
    scanf("%s",encInfo->magic_string);
                
    // Remove newline character that fgets may capture
    encInfo->magic_string[strcspn(encInfo->magic_string, "\n")] = 0;
    if(strlen(encInfo->magic_string)!=3)
        {
            printf("magic string should be only 3 char long");
            return e_failure;
        }
                

    // Use the magic_string from the structure directly
    encode_data_to_image(encInfo->magic_string, strlen(encInfo->magic_string), encInfo->fptr_src_image, encInfo->fptr_stego_image);
    return e_success;
}

Status encode_data_to_image(char * data, int size, FILE *fptr_src_image, FILE *fptr_stego_image)
{
    char image[8];
    for(int i=0;i<size;i++)
    {
        fread(image,8,1,fptr_src_image);
        encode_byte_to_lsb(data[i],image);
        fwrite(image,8,1,fptr_stego_image);
    }
}

Status encode_byte_to_lsb (char data, char *image_buffer)
{
    for (int i=7;i>=0;i--)
    {
        image_buffer[7-i] = ((data >> i) & 1) | (image_buffer[7-i] & ~1) ;
    }
    return e_success;
}

Status encode_size_to_lsb (char data, char *image_buffer)
{
    for (int i=31;i>=0;i--)
    {
        image_buffer[31-i] = ((data >> i) & 1) | (image_buffer[31-i] & ~1) ;
    }
    return e_success;
}

Status encode_secret_file_extn_size(int size, FILE *fptr_src_image, FILE *fptr_stego_image)
{
    char str[32];
    fread(str,32,1,fptr_src_image);
    encode_size_to_lsb(size,str);
    fwrite(str,32,1,fptr_stego_image);
    return e_success;
}
Status encode_secret_file_extn(const char *file_extn, EncodeInfo *encInfo)
{
    encode_data_to_image((char*) file_extn,strlen(file_extn),encInfo->fptr_src_image,encInfo->fptr_stego_image);

    return e_success;
}
Status encode_secret_file_size(long file_size,EncodeInfo *encInfo)
{
    char arr[32];
    fread(arr,32,1,encInfo->fptr_src_image);
    encode_size_to_lsb(file_size,arr);
    fwrite(arr,32,1,encInfo->fptr_stego_image);
    return e_success;
}
Status encode_secret_file_data(EncodeInfo *encInfo)
{
    fseek(encInfo->fptr_secret, 0, SEEK_SET);
    char str[encInfo->size_secret_file];
    fread(str,encInfo->size_secret_file,1,encInfo->fptr_secret);
    encode_data_to_image(str,strlen(str),encInfo->fptr_src_image,encInfo->fptr_stego_image);
    return e_success;
}

Status copy_remaining_image_data(FILE *fptr_src,FILE *fptr_dest)
{
    char ch;
    while((fread(&ch,1,1,fptr_src)) > 0)
    {
        fwrite(&ch,1,1,fptr_dest);
    }
    return e_success;
}

Status do_encoding(EncodeInfo *encInfo)
{
    if(open_files(encInfo) == e_success)
    {
        printf("Open files is success\n");
        if(check_capacity(encInfo) == e_success)
        {
            printf("check capacity is successful\n");
            if(copy_bmp_header(encInfo->fptr_src_image,encInfo->fptr_stego_image) == e_success)
            {
                printf("Copied bmp file successful\n");
                if(encode_magic_string(encInfo) == e_success)
                {
                    printf("Encoded magic string succcessful.\n");
                    strcpy(encInfo->extn_secret_file,strstr(encInfo->secret_fname,"."));
                    if(encode_secret_file_extn_size(strlen(encInfo->extn_secret_file),encInfo->fptr_src_image, encInfo->fptr_stego_image) == e_success)
                    {
                        printf("Encode secret file extension size successful.\n");
                        if(encode_secret_file_extn(encInfo->extn_secret_file,encInfo) == e_success)
                        {
                            printf("Encode secret file extension successful.\n");
                            if(encode_secret_file_size(encInfo->size_secret_file,encInfo) == e_success)
                            {
                                printf("Encode secret file size is successful.\n");
                                if(encode_secret_file_data(encInfo) == e_success)
                                {
                                    printf("secret file data encoded.\n");
                                    if(copy_remaining_image_data(encInfo->fptr_src_image,encInfo->fptr_stego_image) == e_success)
                                    {
                                        printf("Remaining imaga data is copied\n");
                                        return e_success;
                                    }
                                    else
                                    {
                                        printf("Failed to copy remaining data\n");
                                    }
                                }
                                else
                                {
                                    printf("Failed to encode secret file data\n");
                                }
                            }
                            else
                            {
                                printf("Failed to encode secret file size\n");
                            }
                        }
                        else
                        {
                           printf("Failed to encode secret file extension\n");
                        }

                    }
                    else
                    {
                        printf("Failed to encode secret file size extension\n");
                        return e_failure;
                    }
                }
                else
                {
                    printf("Failed to encode magic string\n");
                    return e_failure;
                }
            }
            else
            {
                printf("Failed to copy .bmp files\n");
                return e_failure;
            }
        }
        else
        {
            printf("failed to check capacity\n");
            return e_failure;
        }
    }
    else
    {
        printf("Open files is failed");
    }
        return e_success;
}
